/*
 * 
 * This file is part of the Java Design Patterns project. 
 * It is also also needed for things such as instances of ".replaceAll" and ".split" in the Java language.
 * 
 */

public class Pattern {

}
