Hi there. This will serve as a mk.2 of v0.1 of the Project

Date Format: MM/DD/YYYY-HH:MM:(12)

In this version of the program, instead of using a creating just 1 login screen and guessing if its the admin or a teaching staff that logs in,
this version of the program will make it so that the in the "Displays.displayStartMenu" has an extra option for the Admin and Teaching Staff.

This is to make it so that there is less confusion on the programmers POV on who logs in and what functionalities they have access they can do.
@csonza 05/10/2025-08:34:AM


v0.3
Finally managed to make the entire Admin fully functional :happy-face-with-teart-eyes:. TeachingStaff is all that is left
@csonza 05/11/2025-02:01:PM

v0.4
TeachingStaff login and logout has been made successfully.
@csonza 05/11/2025-08:22:PM

v0.5
All Functionalities in the program have now been made. All that is left is file Printing of each section in a formatted Text File.
@csonza 05/12/2025-01:57:AM

v0.6
Added input validation and error handling for Displays.gradeStudentsInSectionCourseConsole
@csonza 05/12/2025-07:45:AM

v0.7
99% of all funcitonalities have been made. Prod Ready
@csonza 05/12/2025-09:32:AM

v0.8
Code Review. Found some bugs, TODO is close the scanner in the teachingStaff menu. Semi-ditched admin records function as too difficult at the time.
@csonza 05/12/2025-09:32:AM